const e={"Ninja Kamui":{date:"22/09/2026",rating:4,spice:"spicy",review:"Somehwat Good, Basic Storyline of Friends Quarrel."}};export{e as a};
