export const GITHUB_BUTTON_HASH = "645ab8885aad";
export const GITHUB_BUTTON_SRC = "/buttons/github-button.645ab8885aad.png";

export const TRYHACKME_BUTTON_HASH = "723a0f2c4cb4";
export const TRYHACKME_BUTTON_SRC = "/buttons/tryhackme-button.723a0f2c4cb4.png";
