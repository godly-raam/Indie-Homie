export const LAST_UPDATED = "2026-11-20";
